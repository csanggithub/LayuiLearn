# 简介

这是一个巴爷商城的微信小应用版本，是[巴爷微信商城](https://wechat.bayekeji.com)的简单版本。

# 功能

首页商品浏览，分类商品浏览，加入购物车，编辑收货地址，通过API与后端通信（获取商品列表、提交订单）。

需要后台 JSON API 应用的配合（未开源）

# 屏幕截图

![a](http://although2013.com/images/wechat_applet_1.png)
![a](http://although2013.com/images/wechat_applet_2.png)
![a](http://although2013.com/images/wechat_applet_3.png)
