class BaseController < ActionController::API
  include BaseHelper
end
