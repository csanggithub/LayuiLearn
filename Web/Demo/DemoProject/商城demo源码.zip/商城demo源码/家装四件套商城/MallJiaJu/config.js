var config = {

  APPID     :'McTxMpyh',
  HTTP_BASE_URL :'https://saas.yunfan.huosu.com/api/index.php',
}

module.exports = config;
