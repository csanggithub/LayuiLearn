using System;

namespace Model {

	[Serializable]
	public enum DataSort {
		NONE = 0,
		ASC = 1,
		DESC = 2
	}
}
