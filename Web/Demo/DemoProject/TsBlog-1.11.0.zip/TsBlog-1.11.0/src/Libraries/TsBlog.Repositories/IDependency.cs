﻿namespace TsBlog.Repositories
{
    /// <summary>
    /// 依赖注入的接口约束
    /// </summary>
    public interface IDependency
    {
    }
}