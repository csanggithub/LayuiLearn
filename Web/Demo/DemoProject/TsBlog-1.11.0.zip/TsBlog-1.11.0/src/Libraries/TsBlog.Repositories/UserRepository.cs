﻿using TsBlog.Domain.Entities;

namespace TsBlog.Repositories
{
    public class UserRepository : GenericRepository<User>, IUserRepository
    {

    }
}