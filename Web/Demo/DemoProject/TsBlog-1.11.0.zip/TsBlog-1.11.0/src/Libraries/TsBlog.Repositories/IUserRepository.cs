﻿using TsBlog.Domain.Entities;

namespace TsBlog.Repositories
{
    public interface IUserRepository : IRepository<User>
    {

    }
}