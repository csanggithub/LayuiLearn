#easyui-super-theme
以前写的一套easyui皮肤，flat ui的配色，字体图标用的是fontawesome  
这是网址http://fontawesome.dashgame.com/

现在都流行vue，react组件库，不知道现在这东西用的人还多不多，多的话就抽空完善一下，喜欢的话就顺手给个星吧！~

## 用法
皮肤是基于gray主题的
1. 引入gray主题下的easyui.css和根目录css文件夹下的一个主题css  
`<link rel="stylesheet" type="text/css" href="easyui/themes/gray/easyui.css" />`  
`<link rel="stylesheet" type="text/css" href="css/superBlue.css" />`
2. 引入字体图标css `<link rel="stylesheet" type="text/css" href="easyui/themes/icons/css/font-awesome.min.css" />`
3. 引入super.js `<script src="js/super.js" type="text/javascript" charset="utf-8"></script>`

## 部分截图
![image](http://7s1rqe.com1.z0.glb.clouddn.com/easyui-blue.png)
![image](http://7s1rqe.com1.z0.glb.clouddn.com/easyui-green.png)
![image](http://7s1rqe.com1.z0.glb.clouddn.com/easyui-yellow.png)
![image](http://7s1rqe.com1.z0.glb.clouddn.com/easyui-blueDark.png)
![image](http://7s1rqe.com1.z0.glb.clouddn.com/easyui-super.png)
![image](http://7s1rqe.com1.z0.glb.clouddn.com/easyui-super2.png)
![image](http://7s1rqe.com1.z0.glb.clouddn.com/easyui-super3.png)
