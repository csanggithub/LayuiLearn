﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using  NBCZ.DAL;
using  NBCZ.Model;

namespace NBCZ.BLL
{
    public partial class  Pub_UserFunctionBLL
    {
        Pub_UserFunctionDAL dal=new Pub_UserFunctionDAL();
    }
}
