﻿using NBCZ.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBCZ.BLL
{
    public partial class V_PubUser_DeptBLL : BaseService<V_PubUser_Dept>
    {
    }
}
