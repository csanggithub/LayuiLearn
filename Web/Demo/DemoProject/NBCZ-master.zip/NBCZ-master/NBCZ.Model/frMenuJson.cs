﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBCZ.Model
{
    public class frMenuJson
    {
        public string menuId { get; set; }
        public string menuName { get; set; }
        public string menuIcon { get; set; }
        public string menuHref { get; set; }
        public string parentMenuId { get; set; }
    }
}
