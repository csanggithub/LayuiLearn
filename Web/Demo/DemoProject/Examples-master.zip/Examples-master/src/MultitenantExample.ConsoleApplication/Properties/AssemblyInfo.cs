﻿using System.Reflection;

[assembly: AssemblyTitle("MultitenantExample.ConsoleApplication")]
