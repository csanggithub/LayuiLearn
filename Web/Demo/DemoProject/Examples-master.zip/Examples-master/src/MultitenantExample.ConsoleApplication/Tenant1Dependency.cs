﻿using System;

namespace MultitenantExample.ConsoleApplication
{
    /// <summary>
    /// Tenant-specific dependency for Tenant 1.
    /// </summary>
    public class Tenant1Dependency : BaseDependency
    {
    }
}
