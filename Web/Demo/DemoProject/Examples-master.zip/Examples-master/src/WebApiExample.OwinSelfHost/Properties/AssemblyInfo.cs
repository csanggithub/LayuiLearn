﻿using System.Reflection;

[assembly: AssemblyTitle("WebApiExample.OwinSelfHost")]
[assembly: AssemblyProduct("WebApiExample.OwinSelfHost")]
[assembly: AssemblyCopyright("Copyright ©  2014")]
[assembly: AssemblyVersion("1.0.0.0")]
