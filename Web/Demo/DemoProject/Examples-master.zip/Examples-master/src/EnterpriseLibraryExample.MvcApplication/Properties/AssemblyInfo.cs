﻿using System.Reflection;

[assembly: AssemblyTitle("EnterpriseLibraryExample.MvcApplication")]
