﻿using System;

namespace MultitenantExample.MvcApplication.Dependencies
{
    /// <summary>
    /// Tenant-specific dependency for Tenant 1.
    /// </summary>
    public class Tenant1Dependency : BaseDependency
    {
    }
}
