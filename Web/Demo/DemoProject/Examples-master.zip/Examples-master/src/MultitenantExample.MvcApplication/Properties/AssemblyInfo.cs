﻿using System.Reflection;

[assembly: AssemblyTitle("MultitenantExample.MvcApplication")]
