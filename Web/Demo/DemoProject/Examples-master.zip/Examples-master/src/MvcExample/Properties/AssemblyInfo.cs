﻿using System.Reflection;

[assembly: AssemblyTitle("MvcExample")]
[assembly: AssemblyProduct("MvcExample")]
[assembly: AssemblyVersion("1.0.0.0")]
