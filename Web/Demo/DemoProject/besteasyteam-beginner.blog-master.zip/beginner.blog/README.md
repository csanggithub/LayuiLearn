基于layui + asp.net mvc + ef + autofac 的一个个人博客系统
功能如下：
后台：
1.文章管理
2.分类管理
3.设置
4.日志管理
前台
1.显示后台发布的文章信息
2.评论功能

开发环境：
vs2013 + 
sql server2008r2 +
项目演示地址：
管理后台：[http://beginner.zhengjinfan.cn/manage](http://beginner.zhengjinfan.cn/manage)
 1.登录名：admin
 2.密码：admin

前台：[http://beginner.zhengjinfan.cn/manage](http://beginner.zhengjinfan.cn/)
问答社区：[http://fly.layui.com/jie/5081.html](http://fly.layui.com/jie/5081.html)
有啥好的建议可以在社区中提出。

最近该项目在参加由fly社区举办的最佳案例大赛，如果可以的话，可以帮我点个赞哦，谢谢啦。
活动地址：[http://fly.layui.com/case/2016/](http://fly.layui.com/case/2016/) 项目名称：Beginner博客