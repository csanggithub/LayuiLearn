using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using demo.Roles.Dto;
using demo.Users.Dto;

namespace demo.Users
{
    public interface IUserAppService : IAsyncCrudAppService<UserDto, long, PagedResultRequestDto, CreateUserDto, UserDto>
    {
        Task<ListResultDto<RoleDto>> GetRoles();

        Task ChangeLanguage(ChangeUserLanguageDto input);
    }
}
