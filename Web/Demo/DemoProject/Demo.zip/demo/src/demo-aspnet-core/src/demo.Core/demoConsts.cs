namespace demo
{
    public class demoConsts
    {
        public const string LocalizationSourceName = "demo";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
