using Microsoft.AspNetCore.Antiforgery;
using demo.Controllers;

namespace demo.Web.Host.Controllers
{
    public class AntiForgeryController : demoControllerBase
    {
        private readonly IAntiforgery _antiforgery;

        public AntiForgeryController(IAntiforgery antiforgery)
        {
            _antiforgery = antiforgery;
        }

        public void GetToken()
        {
            _antiforgery.SetCookieTokenAndHeader(HttpContext);
        }
    }
}
