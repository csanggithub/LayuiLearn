import { Component, OnInit, Injector } from '@angular/core';


@Component({
  selector: 'layout-sidebar',
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent {

  constructor(
  ) {
  }
}
