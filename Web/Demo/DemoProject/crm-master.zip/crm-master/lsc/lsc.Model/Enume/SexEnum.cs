﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lsc.Model.Enume
{
    public enum SexEnum
    {
        /// <summary>
        /// 男
        /// </summary>
        Man = 1,
        /// <summary>
        /// 女
        /// </summary>
        Woman = 2
    }
}
